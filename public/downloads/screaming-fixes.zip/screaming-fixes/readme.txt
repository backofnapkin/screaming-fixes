=== Screaming Fixes ===
Contributors: ftebrett
Tags: screaming frog, seo, broken links, redirects, alt text
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bulk-fix SEO issues from Screaming Frog crawls—broken links, redirects, alt text, titles, meta descriptions, and more.

== Description ==

Finding SEO problems is easy. Fixing them sucks. Screaming Frog finds the issues, but you're still stuck manually fixing hundreds of broken links, missing alt tags, and redirect chains one by one.

**Screaming Fixes bridges that gap.** Import your Screaming Frog CSV exports and fix issues in bulk—directly in WordPress.

= Who Is This For? =

SEOs and site owners who use Screaming Frog SEO Spider for technical audits. If you've ever stared at a spreadsheet of 500 broken links wondering how you'll fix them all, this plugin is for you.

= 9 SEO Fix Modules =

**Broken Links**
Upload your "All Inlinks" CSV from Screaming Frog. See every broken internal link, the pages they're on, and fix or remove them in bulk. AI suggestions help find the best replacement URL.

**Redirect Chains**
Fix chains, loops, and temporary redirects from one CSV. Flatten multi-hop redirects to their final destination with one click. Stop losing PageRank through unnecessary hops.

**Image Alt Text**
Find images missing alt text across your site. Generate SEO-friendly alt text using AI or write your own. Apply fixes in bulk.

**Page Titles**
Fix missing, duplicate, or over-length title tags. See character counts, get AI suggestions, and update titles without leaving the plugin.

**Meta Descriptions**
Same workflow for meta descriptions. Find pages missing descriptions, generate optimized copy with AI, and apply changes in bulk.

**Internal Link Builder**
Upload your crawl data to find pages that need more internal links. Build contextual links to boost priority pages and improve site architecture.

**Orphan Pages**
Use Screaming Frog's Orphan Pages report with the Internal Link Builder to find stranded pages with no internal links pointing to them. Connect them back into your site structure.

**Backlink Reclaim**
External sites linking to your 404 pages? Don't let that link equity go to waste. Scan for broken backlinks (via DataForSEO API) and create redirects to reclaim the value.

**Backlink Evaluator**
Get premium-level backlink analysis powered by DataForSEO—free. View your complete backlink profile with domain authority, anchor text distribution, dofollow/nofollow ratios, and lost link tracking. Export detailed reports for client work or competitive analysis.

= Integrations =

* **Screaming Frog SEO Spider** - Import CSV exports directly
* **Claude AI** (optional) - Get intelligent fix suggestions for alt text, titles, meta descriptions, and replacement URLs
* **Redirect Plugins** - Create redirects through Yoast SEO, Rank Math, or Redirection plugin
* **SEO Plugins** - Extract focus keywords from Yoast, Rank Math, or AIOSEO for context-aware suggestions
* **DataForSEO** (optional) - Power the Backlink Reclaim and Backlink Evaluator modules with fresh backlink data. Free scans included—no API key required.

= Key Features =

* Bulk fix hundreds of issues in minutes, not hours
* Non-destructive: All changes are logged
* Preview changes before applying
* Export fixed items for reporting
* Works with any Screaming Frog crawl
* Bulk upload option: Prefer spreadsheets? Add a column to your CSV with fixes and upload. Review and approve before applying.

== Installation ==

1. Upload the `screaming-fixes` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Tools > Screaming Fixes** to access the dashboard
4. (Optional) Add your Claude API key in Settings for AI-powered suggestions
5. (Optional) Add DataForSEO credentials for the Backlink Reclaim module

= Getting Started =

1. Run a crawl in Screaming Frog SEO Spider
2. Export the relevant report as CSV (e.g., "All Inlinks" for broken links)
3. Upload the CSV to the matching module in Screaming Fixes
4. Review suggested fixes, edit as needed
5. Apply fixes in bulk

== Frequently Asked Questions ==

= Do I need Screaming Frog to use this plugin? =

Yes. This plugin is designed specifically to process CSV exports from Screaming Frog SEO Spider. It's the bridge between finding issues (Screaming Frog) and fixing them (WordPress).

= Is Screaming Frog free? =

Screaming Frog offers a free version that crawls up to 500 URLs. For larger sites, you'll need their paid license. This plugin works with exports from both versions.

= Do I need an API key? =

Not required. The plugin works without any API keys. However:

* **Claude API key** (optional) - Enables AI-powered suggestions for alt text, titles, meta descriptions, and replacement URLs. Get one at [console.anthropic.com](https://console.anthropic.com/)
* **DataForSEO credentials** (optional) - Unlocks unlimited scans for Backlink Reclaim and Backlink Evaluator. Free scans are included without an API key.

= Will this plugin break my site? =

The plugin is designed to be safe:

* All changes are logged and can be downloaded as CSV
* You preview every change before applying
* Changes are made through WordPress APIs, not direct database edits

= What CSV files does each module accept? =

* **Broken Links** - "All Inlinks" export filtered to broken responses
* **Redirect Chains** - "Redirect Chains" report
* **Image Alt Text** - "Images" report filtered to missing alt text
* **Page Titles** - "Page Titles" report
* **Meta Descriptions** - "Meta Description" report
* **Internal Link Builder** - "All Inlinks" or custom crawl data
* **Orphan Pages** - "Orphan Pages" report (use with Internal Link Builder)

= Does this work with Sitebulb or other crawlers? =

The plugin is optimized for Screaming Frog CSV exports. However, if you format your CSV with the same column headers, it will work with data from any crawler. It just won't be as seamless as using Screaming Frog directly.

= What does Debug mode do? =

Debug mode writes diagnostic information to your server's error log when processing CSV uploads. Enable it temporarily when troubleshooting upload issues, then disable it after. Logs appear in your server's error log or WordPress debug.log (if WP_DEBUG_LOG is enabled).

== Screenshots ==

1. Dashboard overview - See all modules and recent activity at a glance
2. Broken Links module - Upload CSV, review issues, and fix in bulk
3. Image Alt Text - AI-generated suggestions for missing alt text
4. Redirect Chains - Flatten multi-hop redirects with one click
5. Settings - Configure API keys and preferences
6. Activity Log - Track all changes and export as CSV

== Changelog ==

= 1.0.0 =
* Initial release
* 9 fix modules: Broken Links, Redirect Chains, Image Alt Text, Page Titles, Meta Descriptions, Internal Link Builder, Orphan Pages, Backlink Reclaim, Backlink Evaluator
* Claude AI integration for suggestions
* DataForSEO integration for backlink scanning
* Full change logging with CSV export
* Redirect plugin integrations (Yoast, Rank Math, Redirection)
* Bulk upload option for power users

== Upgrade Notice ==

= 1.0.0 =
Initial release. Start bulk-fixing your Screaming Frog audit findings.
